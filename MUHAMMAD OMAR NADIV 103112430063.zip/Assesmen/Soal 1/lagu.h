#ifndef lagu_h
#define lagu_h

using namespace std;

struct Node {
    string data;
    Node* next;
    Node* prev;
};

extern Node* head;

void tambahLaguDiAwal(string judulLagu);
void tampil();

#endif