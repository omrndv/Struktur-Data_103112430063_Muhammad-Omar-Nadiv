#include <iostream>
#include "lagu.h"
using namespace std;

Node* head = NULL;

void tambahLaguDiAwal(string judulLagu) {
    Node* newNode = new Node();
    newNode->data = judulLagu;
    newNode->next = NULL;
    newNode->prev = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;

        head = newNode;
    }

    cout << "Lagu '" << judulLagu << "' ditambahkan ke awal playlist." << endl;
}

void tampil() {
    Node* current = head;
    cout << "--- Isi Playlist (dari awal) ---" << endl;
    while (current != NULL) {
        cout << current->data << " <-> ";
        current = current->next;
    }
    cout << "NULL" << endl;
}
