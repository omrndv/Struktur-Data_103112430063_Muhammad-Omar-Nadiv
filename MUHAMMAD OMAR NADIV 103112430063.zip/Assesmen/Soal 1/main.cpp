#include <iostream>
using namespace std;
#include "lagu.h"

int main() {
    head = NULL;

    cout << "----------------------------------" << endl;
    cout << "Muhammad Omar Nadiv - 103112430063" << endl;
    cout << "----------------------------------" << endl;

    tambahLaguDiAwal("Melukis Senja - Budi Doremi");
    tambahLaguDiAwal("Halu - Feby Putri");

    cout << endl;

    tampil();

    return 0;
}
