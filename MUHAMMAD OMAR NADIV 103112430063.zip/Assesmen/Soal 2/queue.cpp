#include <iostream>
#include "queue.h"

using namespace std;

int queueArr[10];
int front = -1;
int rear = -1;

void enqueue(int idDokumen) {
    if (rear >= 9) return;

    if (front == -1) {
        front = 0;
    }

    rear++;

    queueArr[rear] = idDokumen;

    cout << "Dokumen " << idDokumen << " masuk antrian." << endl;
}

int dequeue() {
    if (front == -1 || front > rear) return -1;

    int dokumenKeluar = queueArr[front];

    front++;

    return dokumenKeluar;
}