#ifndef QUEUE_H
#define QUEUE_H

extern int queueArr[10];
extern int front;
extern int rear;

void enqueue(int idDokumen);
int dequeue();

#endif
