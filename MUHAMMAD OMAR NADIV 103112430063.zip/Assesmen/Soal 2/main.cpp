#include <iostream>
#include "queue.h"

using namespace std;

int main() {
    cout << "----------------------------------" << endl;
    cout << "Muhammad Omar Nadiv - 103112430063" << endl;
    cout << "----------------------------------" << endl;
    
    enqueue(1);
    enqueue(2);

    cout << "Mencetak: " << dequeue() << endl;

    enqueue(3);

    cout << "Mencetak: " << dequeue() << endl;
    cout << "Mencetak: " << dequeue() << endl;

    return 0;
}